import { Router } from "express";

import {
  listarUsuarios,
  criarUsuario,
  deletarUsuario,
  atualizarUsuario,
  validarUsuario,
  perfil,
  login,
} from "../controllers/userController";
import { authMiddleware } from "../middleware/auth";

const router = Router();

router.get("/", listarUsuarios);
router.post("/", criarUsuario);
router.put("/:id", atualizarUsuario);
router.delete("/:id", deletarUsuario);

router.post("/validar", validarUsuario);
router.post("/login", login);
router.get("/perfil", authMiddleware, perfil);

export default router;
